# Description des flux FHIR - Médicosocial - Transfert de données DUI CDA v1.0.1

## Description des flux FHIR

* [Synthèse des flux](description_flux_synthese.md)
* [Flux 1 - Ajout d'un lot de documents](description_flux_2_ajout_lot_doc.md)

