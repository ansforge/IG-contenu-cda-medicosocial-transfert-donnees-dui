# ans.cda.fr.tddui#1.0.1: Médicosocial - Transfert de données DUI CDA(en)

## Pages

* [Accueil](index.md)
* [Evénement](contenu_evenement.md)
* [Flux 1 - Ajout d'un lot de documents](description_flux_2_ajout_lot_doc.md)
* [Sejour](contenu_sejour.md)
* [Spécifications CDA](specs_cda.md)
* [Téléchargements et usages](downloads.md)
* [Evaluation](contenu_evaluation.md)
* [Documentation](documentation.md)
* [Documents ajoutés](contenu_documents_ajoutes.md)
* [Documents de référence](annexes_documents_reference.md)
* [Autres ressources](autres_ressources.md)
* [Spécifications FHIR](specs_fhir.md)
* [Jeux de Valeurs CDA](terminology_cda.md)
* [Structure générale du document CDA](contenu_dossier_structure_cda.md)
* [Ressources FHIR](artifacts.md)
* [Sécurité](securite.md)
* [Ressources de conformité](ressources_conformite.md)
* [Professions du médico-social](annexes_codes_professions_roles_modes_exercices.md)
* [Ressources CDA](ressources_cda.md)
* [Description des flux FHIR](description_flux.md)
* [Contenu du dossier CDA](contenu_dossier.md)
* [Entête du document CDA](contenu_dossier_entete_cda.md)
* [Synthèse des flux](description_flux_synthese.md)
* [Spécifications fonctionnelles](sfe.md)
* [Solutions de tests](tests.md)
* [Acronymes](annexes_acronymes.md)
* [Corps du document CDA](contenu_dossier_corps_cda.md)
* [Terminologies et jeux de valeurs](annexes_nomenclatures.md)
* [Site de l'ANS](site_ans.md)
* [Contexte](contenu_dossier_contexte.md)
* [Historique des changements](changes.md)
* [Eléments transversaux](contenu_elements_transversaux.md)
* [Mapping CDA du modèle de contenu DUI](mapping_fonctionnelle_technique.md)
* [Annexes](annexes.md)
* [Couvertures sociales](contenu_couvertures.md)

## Resources

### Resource Profiles

* [TDDUI Bundle](StructureDefinition-tddui-bundle.md)
* [TDDUI Document Reference](StructureDefinition-tddui-documentreference.md)

### CapabilityStatements

* [TDDUI-Consommateur](CapabilityStatement-TDDUIConsommateur.md)
* [TDDUI-Producteur](CapabilityStatement-TDDUIProducteur.md)

### ImplementationGuides

* [Médicosocial - Transfert de données DUI CDA](ImplementationGuide-ans.cda.fr.tddui.md)

### Examples

* [TDDUIBundleExample (Bundle)](Bundle-TDDUIBundleExample.md)
* [TDDUIDocumentReferenceExample (DocumentReference)](DocumentReference-TDDUIDocumentReferenceExample.md)
