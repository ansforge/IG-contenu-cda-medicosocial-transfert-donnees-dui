# Spécifications CDA - Médicosocial - Transfert de données DUI CDA v1.0.1

* [**Table of Contents**](toc.md)
* [**Autres ressources**](autres_ressources.md)
* **Spécifications CDA**

## Spécifications CDA

Si vous n'êtes pas redirigé automatiquement, [cliquez ici pour consulter les spécifications CDA](https://hl7.org/cda/stds/core/).

