# Spécifications fonctionnelles - Médicosocial - Transfert de données DUI CDA v1.0.1

* [**Table of Contents**](toc.md)
* **Spécifications fonctionnelles**

## Spécifications fonctionnelles

* Les spécifications fonctionnelles sont disponibles dans le guide d'implémentation [Médicosocial - Transfert de données DUI.](https://interop.esante.gouv.fr/ig/fhir/tddui/2.0.0/sfe.html)

