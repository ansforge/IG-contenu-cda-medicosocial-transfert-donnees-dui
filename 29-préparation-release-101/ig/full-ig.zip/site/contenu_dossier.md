# Contenu du dossier CDA - Médicosocial - Transfert de données DUI CDA v1.0.1

* [**Table of Contents**](toc.md)
* **Contenu du dossier CDA**

## Contenu du dossier CDA

* [Contexte](contenu_dossier_contexte.md)
* [Mapping CDA du modèle de contenu DUI](mapping_fonctionnelle_technique.md)
* [Structure générale du document CDA](contenu_dossier_structure_cda.md)
* [Entête du document CDA](contenu_dossier_entete_cda.md)
* [Corps du document CDA](contenu_dossier_corps_cda.md)
* [Jeux de Valeurs CDA](terminology_cda.md)

