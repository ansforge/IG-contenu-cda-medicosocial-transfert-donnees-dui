# Jeux de Valeurs CDA - Médicosocial - Transfert de données DUI CDA v1.0.1

* [**Table of Contents**](toc.md)
* [**Contenu du dossier CDA**](contenu_dossier.md)
* **Jeux de Valeurs CDA**

## Jeux de Valeurs CDA

<iframe src="./cda/terminology.html" width="auto" height="1000"></iframe>

