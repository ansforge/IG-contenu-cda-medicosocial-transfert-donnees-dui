# Spécifications FHIR - Médicosocial - Transfert de données DUI CDA v1.0.1

* [**Table of Contents**](toc.md)
* [**Autres ressources**](autres_ressources.md)
* **Spécifications FHIR**

## Spécifications FHIR

Si vous n'êtes pas redirigé automatiquement, [cliquez ici pour consulter les spécifications FHIR](http://hl7.org/fhir/R4/index.html).

