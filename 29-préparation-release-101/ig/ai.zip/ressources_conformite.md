# Ressources de conformité - Médicosocial - Transfert de données DUI CDA v1.0.1

* [**Table of Contents**](toc.md)
* **Ressources de conformité**

## Ressources de conformité

* [Ressources FHIR](artifacts.md)
* [Ressources CDA](ressources_cda.md)

