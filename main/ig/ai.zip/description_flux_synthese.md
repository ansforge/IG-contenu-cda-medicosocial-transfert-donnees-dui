# Synthèse des flux - Médicosocial - Transfert de données DUI CDA v1.0.0

* [**Table of Contents**](toc.md)
* [**Description des flux FHIR**](description_flux.md)
* **Synthèse des flux**

## Synthèse des flux

**Les flux présentés ci-dessous doivent utiliser HTTPS.**

* Processus métier: * Transférer les données d’un logiciel DUI vers un SI tiers

* Processus métier: * Flux 1.1 - Ajout d'un lot de documents : interaction « transaction » de FHIR
* Flux 1.2 - Résultat de l'ajout d'un lots documents : réponse à la requête HTTP POST
Lien vers la description détaillée :[flux 1](description_flux_2_ajout_lot_doc.md)

