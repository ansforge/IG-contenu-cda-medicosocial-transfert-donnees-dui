# Mapping CDA du modèle de contenu DUI - Médicosocial - Transfert de données DUI CDA v1.0.1

* [**Table of Contents**](toc.md)
* [**Contenu du dossier CDA**](contenu_dossier.md)
* **Mapping CDA du modèle de contenu DUI**

## Mapping CDA du modèle de contenu DUI

 Ce mapping représente les données fonctionnelles trouvant leur équivalence dans l'actuelle version des spécifications techniques. 

## Données administratives

#### Mapping Usager

#### Mapping Séjour

### Partie Accompagnement

#### Mapping Evaluation

### Partie Coordination des acteurs

#### Mapping Evènement de l'agenda

