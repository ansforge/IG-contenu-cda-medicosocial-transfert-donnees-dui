# Documentation - Médicosocial - Transfert de données DUI CDA v1.0.0

* [**Table of Contents**](toc.md)
* [**Autres ressources**](autres_ressources.md)
* **Documentation**

## Documentation

Si vous n'êtes pas redirigé automatiquement, [cliquez ici pour voir la documentation](https://interop.esante.gouv.fr/ig/documentation/).

