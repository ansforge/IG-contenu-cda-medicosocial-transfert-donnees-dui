# Terminologies et jeux de valeurs - Médicosocial - Transfert de données DUI CDA v1.0.0

* [**Table of Contents**](toc.md)
* [**Annexes**](annexes.md)
* **Terminologies et jeux de valeurs**

## Terminologies et jeux de valeurs

| | |
| :--- | :--- |
| Serveur Multi-Terminologies | [https://smt.esante.gouv.fr](https://smt.esante.gouv.fr) |
| Serveur Multi-Terminologies FHIR | [https://smt.esante.gouv.fr/fhir](https://smt.esante.gouv.fr/fhir) |
| IG Terminologies et jeux de valeurs | [IG-terminologie-de-sante](https://interop.esante.gouv.fr/terminologies/ImplementationGuide/ans.fr.terminologies) |

